import { useState } from 'react';

// Small dataset for demo (can be expanded)
const areaCodeData = {
  "212": { state: "New York", timezone: "Eastern Time" },
  "305": { state: "Florida", timezone: "Eastern Time" },
  "312": { state: "Illinois", timezone: "Central Time" },
  "415": { state: "California", timezone: "Pacific Time" },
  "702": { state: "Nevada", timezone: "Pacific Time" },
  "808": { state: "Hawaii", timezone: "Hawaii-Aleutian Time" }
};

export default function Home() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState(null);

  const handleLookup = () => {
    const code = input.replace(/\D/g, '').slice(0, 3);
    if (areaCodeData[code]) {
      setResult(areaCodeData[code]);
    } else {
      setResult({ state: 'Unknown', timezone: 'Unknown' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-4">US Area Code Lookup</h1>
      <p className="mb-4 text-gray-700">Enter any US area code to find its state and timezone.</p>
      <div className="flex space-x-2 mb-4">
        <input
          type="text"
          placeholder="e.g. 415"
          className="border px-3 py-2 rounded w-40"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          onClick={handleLookup}
        >
          Look Up
        </button>
      </div>
      {result && (
        <div className="text-center mt-4">
          <div><strong>State:</strong> {result.state}</div>

          <div><strong>Timezone:</strong> {result.timezone}</div>
        </div>
      )}
    </div>
  );
}